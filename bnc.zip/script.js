document.addEventListener('DOMContentLoaded', () => {
    // --- Get DOM Elements ---
    const cardNumberInput = document.getElementById('card-number');
    const cardHolderInput = document.getElementById('card-holder');
    const expiryMonthSelect = document.getElementById('expiry-month');
    const expiryYearSelect = document.getElementById('expiry-year');
    const cvvInput = document.getElementById('cvv');

    const cardNumberDisplay = document.getElementById('card-number-display');
    const cardHolderDisplay = document.getElementById('card-holder-display');
    const cardExpiryDisplay = document.getElementById('card-expiry-display');
    const cardCvvDisplay = document.getElementById('card-cvv-display');

    const cardLogo = document.getElementById('card-logo');
    const cardLogoBack = document.getElementById('card-logo-back'); // Optional back logo
    const creditCard = document.querySelector('.credit-card');

    const defaultCardNumber = '#### #### #### ####';
    const defaultCardHolder = 'NOM COMPLET';
    const defaultExpiry = 'MM/AA';

    // --- Populate Date Selects ---
    const currentYear = new Date().getFullYear();
    const currentMonth = new Date().getMonth() + 1; // JS months are 0-indexed

    // Populate Months (01-12)
    for (let i = 1; i <= 12; i++) {
        const month = String(i).padStart(2, '0');
        const option = document.createElement('option');
        option.value = month;
        option.textContent = month;
        expiryMonthSelect.appendChild(option);
    }

    // Populate Years (Current year + 10)
    for (let i = 0; i <= 10; i++) {
        const year = currentYear + i;
        const yearShort = String(year).slice(-2); // Get last 2 digits
        const option = document.createElement('option');
        option.value = yearShort;
        option.textContent = yearShort;
        expiryYearSelect.appendChild(option);
    }

    // --- Input Formatting ---
    cardNumberInput.addEventListener('input', (e) => {
        // Allow only digits and spaces, format with spaces every 4 digits
        let value = e.target.value.replace(/\D/g, ''); // Remove non-digits
        let formattedValue = '';
        for (let i = 0; i < value.length; i++) {
            if (i > 0 && i % 4 === 0) {
                formattedValue += ' ';
            }
            formattedValue += value[i];
        }
        e.target.value = formattedValue;

        // Update card display
        cardNumberDisplay.textContent = formattedValue || defaultCardNumber;

        // Update card logo
        updateCardLogo(value);
    });

    cardHolderInput.addEventListener('input', (e) => {
        let value = e.target.value.toUpperCase(); // Style guide: names often uppercase
        e.target.value = value; // Force uppercase in input as well
        cardHolderDisplay.textContent = value || defaultCardHolder;
    });

    // --- Update Expiry Display ---
    function updateExpiryDisplay() {
        const month = expiryMonthSelect.value || 'MM';
        const year = expiryYearSelect.value || 'AA';
        cardExpiryDisplay.textContent = `${month}/${year}`;
    }
    expiryMonthSelect.addEventListener('change', updateExpiryDisplay);
    expiryYearSelect.addEventListener('change', updateExpiryDisplay);


    // --- CVV Input & Card Flip ---
    cvvInput.addEventListener('input', (e) => {
        // Allow only digits
        e.target.value = e.target.value.replace(/\D/g, '');
        // Update visual display on the back
        cardCvvDisplay.textContent = e.target.value;
    });

    cvvInput.addEventListener('focus', () => {
        creditCard.classList.add('is-flipped');
    });

    cvvInput.addEventListener('blur', () => {
        creditCard.classList.remove('is-flipped');
    });

    // --- Card Logo Logic ---
    function updateCardLogo(number) {
        const firstDigit = number.charAt(0);
        const firstTwoDigits = number.substring(0, 2);

        // Remove existing logo classes
        cardLogo.classList.remove('visa-logo', 'mastercard-logo');
        cardLogoBack.classList.remove('visa-logo', 'mastercard-logo'); // Sync back logo if used

        // Determine logo
        if (firstDigit === '4') {
            cardLogo.classList.add('visa-logo');
            cardLogoBack.classList.add('visa-logo');
        } else if (parseInt(firstTwoDigits) >= 51 && parseInt(firstTwoDigits) <= 55) {
            cardLogo.classList.add('mastercard-logo');
            cardLogoBack.classList.add('mastercard-logo');
        }
        // Add more conditions here for Amex, Discover, etc. if needed
        // else if (firstTwoDigits === '34' || firstTwoDigits === '37') { /* Amex */ }
        // else if (firstDigit === '6') { /* Discover */ }
    }

    // --- Initial State ---
    cardNumberDisplay.textContent = defaultCardNumber;
    cardHolderDisplay.textContent = defaultCardHolder;
    cardExpiryDisplay.textContent = defaultExpiry;
    // Ensure logo area is clear initially
    updateCardLogo('');

}); // End DOMContentLoaded